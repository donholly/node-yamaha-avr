var options = {
  appid: "amzn1.echo-sdk-ams.app.ce2d3517-32b6-4590-b63c-b296496c1778",
  host: "donholly.com",
  port: "5005"
};

module.exports = options;
